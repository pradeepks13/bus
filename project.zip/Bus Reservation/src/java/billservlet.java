/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Kiran H T
 */
public class billservlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
                           out.print("<!DOCTYPE html>\n" +
"<html>\n" +
"<head>\n" +
"<style>\n" +
"table {\n" +
"    border-collapse: collapse;\n" +
"    border-spacing: 0;\n" +
"    width: 100%;\n" +
"    border: 1px solid #ddd;\n" +
"}\n" +
"\n" +
"th, td {\n" +
"    text-align: left;\n" +
"    padding: 16px;\n" +
"}\n" +
"\n" +
"tr:nth-child(even) {\n" +
"    background-color: #f2f2f2\n" +
"}\n" +
"</style>\n" +
"</head>\n" +
"<body>\n" +
"\n");
out.print("<body background=\"https://geeglenews.com/ct-geeglenews/uploads/2017/04/light-blue-background-57743.jpg\">");                
             String bus_id=request.getParameter("bus_id");
             String bank_name=request.getParameter("bank");
              String card_number=request.getParameter("card");
              String cvv=request.getParameter("cvv");
               String expr_date=request.getParameter("date");
                String otp=request.getParameter("pin");
                Dbconnect dbt=new Dbconnect();
                Connection con=dbt.getCon();
                 Statement stmt=con.createStatement();
                 stmt.executeUpdate("insert into bill values('"+bus_id+"','"+bank_name+"','"+card_number+"','"+cvv+"','"+expr_date+"','"+otp+"');");
                  ResultSet res;
                   String query;
                    query="select b.bank_name\n" +
"from bank b,bill c\n" +
"where b.bank_name=c.bank_name and\n" +
"b.card_number=c.card_number and\n" +
"b.cvv=c.cvv and\n" +
"b.expr_date=c.expr_date and\n" +
"b.otp=c.otp";
                     res=stmt.executeQuery(query); 
                      Statement stmt5=con.createStatement();
                       String query5;
                query5="select b.bus_number,b.bus_name,b.from_,b.to_,b.departure_date,b.departure_time,r.seats,r.seats*b.amount as Total from bus b,bill l,reserve r where b.bus_id=l.bus_id and b.from_=r.from_";
               
                ResultSet rs=stmt5.executeQuery(query5);
                  int rowCount=0;
                 out.println("<center><h2>Successfully Confirmed your Tickets</h2></center>");
                   out.println("<p align='center'><table border=1>");
                   ResultSetMetaData Rsmd=rs.getMetaData();
                    int columnCount=Rsmd.getColumnCount();
                     out.println("<tr>");
                  for(int i=0;i<columnCount;i++)
                   {
                       out.println("<th>"+Rsmd.getColumnLabel(i+1)+"</th>");
                   }
                  out.println("</tr>");
                  while(rs.next())
                  {
                      rowCount++;
                      out.println("<tr>");
                      for(int i=0;i<columnCount;i++)
                      {
                          out.println("<td>"+rs.getString(i+1)+"</td>");
                      }
                      out.println("</tr>");
                    }
                      Statement stmt4=con.createStatement();
                      String query4="update bus b,reserve r set b.available_seats=(b.available_seats - r.seats) where b.from_=r.from_ and b.to_=r.to_";
                      stmt4.executeUpdate(query4);
                    Statement stmt1=con.createStatement();
                    String query1;
                    query1="delete from reserve";
                    stmt1.executeUpdate(query1);                      
                      Statement stmt2=con.createStatement();
                    String query2;
                    query2="delete from login";
                    stmt2.executeUpdate(query2);     
                     
                      Statement stmt3=con.createStatement();
                    String query3;
                    query3="delete from bill";
                    stmt3.executeUpdate(query3);  
                     out.println("<center><h2> <a href=\"index.html\"> LOGOUT HERE </a></h2></center><br>");
                     
        } catch (SQLException ex) {
            Logger.getLogger(billservlet.class.getName()).log(Level.SEVERE, null, ex);
        

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(billservlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
