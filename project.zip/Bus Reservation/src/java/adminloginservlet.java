/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Kiran H T
 */
public class adminloginservlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
                          out.print("<!DOCTYPE html>\n" +
"<html>\n" +
"<head>\n" +
"<style>\n" +
"table {\n" +
"    border-collapse: collapse;\n" +
"    border-spacing: 0;\n" +
"    width: 100%;\n" +
"    border: 1px solid #ddd;\n" +
"}\n" +
"\n" +
                                   
 "a:link, a:visited{\n"+
        "display: block; \n"+
	"width: 400px;\n"+
	"font-weight: bold;\n"+
	"background-color: orange;\n"+
	"color: yelow;\n"+
	"text-align: center;\n"+
	"text-transform: uppercase;\n"+
	"padding: 10px;\n"+
	"text-decoration: none;\n"+
	"transition: 2s background-color ease 0s;\n"+
	"border-radius: 5px 4px 5px 4px;\n"+
	"margin-left: auto;\n"+
	"margin-right: auto;\n"+
	"margin-top: 50px;\n"+
"}\n"+                                                                 
"th, td {\n" +
"    text-align: left;\n" +
"    padding: 16px;\n" +
"}\n" +
"\n" +
"tr:nth-child(even) {\n" +
"    background-color: #f2f2f2\n" +
"}\n" +
"</style>\n" +
"</head>\n" +
"<body>\n" +
"\n");
out.print("<body background=\"https://wallpapercave.com/wp/Ugecrd4.jpg\">");                
                 String admin_id=request.getParameter("aname");
                 String password=request.getParameter("pass");
        Dbconnect dbt=new Dbconnect();
            try (Connection con = dbt.getCon()) {
                Statement stmt=con.createStatement();
                  try{
                stmt.executeQuery("select * from adminlogin where admin_id='"+admin_id+"' and password='"+password+"'");
                 out.println("<center><h2> <a href=\"addbus.html\">ADD BUS</a></h2></center><br>");
                  out.println("<center><h2> <a href=\"deletebus.html\">DELETE BUS</a></h2></center><br>");
                   out.println("<center><h2> <a href=\"availableservlet\">VIEW BUSES</a></h2></center><br>");
                    out.println("<center><h2> <a href=\"index.html\">EXIT</a></h2></center><br>");
                  }
                   catch(Exception e){
                      out.println("<center><h2> Please Enter valid details</h2></center><br>");
                       out.println("<center><h2> <a href=\"adminlogin.html\">Back</a></h2></center><br>");
                 }
                      }
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(adminloginservlet.class.getName()).log(Level.SEVERE, null, ex);
        }

        }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
