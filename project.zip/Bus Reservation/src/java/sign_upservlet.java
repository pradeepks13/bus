/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Kiran H T
 */
public class sign_upservlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
                        out.print("<!DOCTYPE html>\n" +
"<html>\n" +
"<head>\n" +
"<style>\n" +
"table {\n" +
"    border-collapse: collapse;\n" +
"    border-spacing: 0;\n" +
"    width: 100%;\n" +
"    border: 1px solid #ddd;\n" +
"}\n" +
"\n" +
"th, td {\n" +
"    text-align: left;\n" +
"    padding: 16px;\n" +
"}\n" +
"\n" +
"tr:nth-child(even) {\n" +
"    background-color: #f2f2f2\n" +
"}\n" +
"</style>\n" +
"</head>\n" +
"<body>\n" +
"\n");
out.print("<body background=\"http://wallpapercave.com/wp/GU3Bqjs.jpg\">");                
            String username=request.getParameter("uname");
            String password=request.getParameter("pass");
            String name=request.getParameter("name");
            String gender=request.getParameter("gender");
            String city=request.getParameter("city");
            String pincode=request.getParameter("pincode");
            String email=request.getParameter("email");
            String phone=request.getParameter("phone");
              Dbconnect dbt=new Dbconnect();
               try (Connection con = (Connection) dbt.getCon()) {
                Statement stmt=con.createStatement();
                stmt.executeUpdate("insert into sign_up(user_id,password,name,gender,city,pincode,email,phone) values('"+username+"','"+password+"','"+name+"','"+gender+"','"+city+"','"+pincode+"','"+email+"','"+phone+"');");
                out.println("<center><h1>Sign-up is  Successfully Completed. Go To </h1></center>");
                 out.println("<center><h2> <a href=\"login.html\"> LOGIN </a></h2></center><br>");
                Statement stmt1=con.createStatement();
                String query="select * from sign_up where user_id='"+username+"' and password='"+password+"'";
                stmt1.executeQuery(query);
                ResultSet Rs=stmt1.getResultSet();
                 int rowCount=0;
                 out.println("<center><h1>Your Database</h1></center>");
                  out.println("<p align='center'><table border=1>");
                  ResultSetMetaData Rsmd=Rs.getMetaData();
                  int columnCount=Rsmd.getColumnCount();
                  out.println("<tr>");
                  for(int i=0;i<columnCount;i++)
                   {
                       out.println("<th>"+Rsmd.getColumnLabel(i+1)+"</th>");
                   }
                   out.println("</tr>");
                    while(Rs.next())
                  {
                      rowCount++;
                      out.println("<tr>");
                      for(int i=0;i<columnCount;i++)
                      {
                          out.println("<td>"+Rs.getString(i+1)+"</td>");
                      }
                      out.println("</tr>");
                   }
            } catch (ClassNotFoundException | SQLException ex) {
                Logger.getLogger(sign_upservlet.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
